﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Principal;
using System.Threading;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.Configuration;

namespace WCF.Performance.Samples
{
    public class WorkflowTestDriver : TestDriver
    {
        int numOrders = 10;
        int numConcurrentCalls = 10;
        MyOrderClient[] clients;
        RequestCompleteHandler[] handlers;
        int completedHandlers;
        ManualResetEvent allHandlersCompleted;

        public WorkflowTestDriver()
        {
        }

        #region Main Method
        public static void Main(string[] args)
        {
            try
            {
                WorkflowTestDriver driver = new WorkflowTestDriver();
                driver.Run(args);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        #endregion Main Method

        protected override void SetupTest()
        {
            ReadConfigSettings();
            allHandlersCompleted = new ManualResetEvent(false);
            clients = new MyOrderClient[numConcurrentCalls];
            handlers = new RequestCompleteHandler[numConcurrentCalls];

            for (int i = 0; i < numConcurrentCalls; i++)
            {
                clients[i] = new MyOrderClient("MyOrderServiceClient");

                handlers[i] = new RequestCompleteHandler(this, clients[i]);
            }

            Console.WriteLine("Test has completed setup:");
            Console.WriteLine("Number of concurrent calls: {0}", this.numConcurrentCalls);
            Console.WriteLine("Number of orders: {0}", this.numOrders);
            Console.WriteLine("Warmup seconds: {0}", this.WarmupSeconds);
            Console.WriteLine("Total run seconds: {0}", this.TotalRunSeconds);
            Console.WriteLine();
        }

        #region Read Config Settings
        void ReadConfigSettings()
        {
            string warmupSecondsString = ConfigurationManager.AppSettings["warmupSeconds"];
            if (warmupSecondsString != null)
            {
                this.WarmupSeconds = int.Parse(warmupSecondsString);
            }

            string totalRunSecondsString = ConfigurationManager.AppSettings["totalRunSeconds"];
            if (totalRunSecondsString != null)
            {
                this.TotalRunSeconds = int.Parse(totalRunSecondsString);
            }

            string numOrdersString = ConfigurationManager.AppSettings["numOrders"];
            if (numOrdersString != null)
            {
                this.numOrders = int.Parse(numOrdersString);
            }

            string numConcurrentCallsString = ConfigurationManager.AppSettings["numConcurrentCalls"];
            if (numConcurrentCallsString != null)
            {
                this.numConcurrentCalls = int.Parse(numConcurrentCallsString);
            }
        }
        #endregion Read Config Settings

        protected override void RunTest()
        {
            Console.WriteLine("Start RunTest");
            for (int i = 0; i < numConcurrentCalls; i++)
            {
                handlers[i].Start();
            }

            allHandlersCompleted.WaitOne();
            Console.WriteLine("RunTest Completed");
        }

        void OnHandlerCompleted()
        {
            int result = Interlocked.Increment(ref completedHandlers);
            if (result == this.numConcurrentCalls)
            {
                allHandlersCompleted.Set();
            }
        }

        #region Request Handler
        class RequestCompleteHandler
        {
            WorkflowTestDriver driver;
            AsyncCallback onGetOrders;
            MyOrderClient client;
            public RequestCompleteHandler(WorkflowTestDriver driver, MyOrderClient client)
            {
                this.driver = driver;
                this.client = client;
                this.onGetOrders = new AsyncCallback(OnGetOrders);
            }

            public void Start()
            {
                Iterate();
            }

            void Iterate()
            {
                IAsyncResult result = client.BeginGetOrders(driver.numOrders, onGetOrders, this);
                if (result.CompletedSynchronously)
                {
                    HandleResult(result);
                }
            }

            void OnGetOrders(IAsyncResult result)
            {
                if (result.CompletedSynchronously)
                {
                    return;
                }

                HandleResult(result);
            }

            void HandleResult(IAsyncResult result)
            {
                Order[] orders = client.EndGetOrders(result);
                if (orders.Length != driver.numOrders)
                {
                    throw new InvalidOperationException("Got wrong data from the service.");
                }

                if (result.CompletedSynchronously)
                {
                    // We should start a new thread to iterate, otherwise we may get into StackOverflow
                }

                if (driver.RunComplete())
                {
                    driver.OnHandlerCompleted();
                    return;
                }

                Iterate();
            }
        }
        #endregion Request Handler
    }

    #region MyOrderClient
    class MyOrderClient : ClientBase<IAsyncOrderService>, IAsyncOrderService
    {
        public MyOrderClient(string endpointConfigurationName)
            : base(endpointConfigurationName)
        {
        }

        public IAsyncResult BeginGetOrders(int numOrders, AsyncCallback callback, object state)
        {
            return this.Channel.BeginGetOrders(numOrders, callback, state);
        }

        public Order[] EndGetOrders(IAsyncResult result)
        {
            return this.Channel.EndGetOrders(result);
        }
    }
    #endregion
}
