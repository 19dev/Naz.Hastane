﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WCF.Performance.Samples
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 1)
            {
                PrintUsage();
                return;
            }

            try
            {
                int numOrders = int.Parse(args[0]);
                Order[] orders = OrderServiceHelper.CreateOrders(numOrders);

                using (OrderSqlHelper helper = new OrderSqlHelper())
                {
                    helper.ClearTables();
                    helper.PopulateOrders(orders);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        static void PrintUsage()
        {
            Console.WriteLine("Usage: {0} <numOrder>",
                System.Reflection.Assembly.GetExecutingAssembly().GetName().Name);
        }
    }
}
