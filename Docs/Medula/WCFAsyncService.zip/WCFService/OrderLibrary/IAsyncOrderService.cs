﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace WCF.Performance.Samples
{
    [ServiceContract(Namespace = ServiceConstants.ServiceContractNamespace,
        Name = ServiceConstants.ServiceName)]
    public interface IAsyncOrderService
    {
        [OperationContract(AsyncPattern=true)]
        IAsyncResult BeginGetOrders(int numOrders, AsyncCallback callback, object state);

        Order[] EndGetOrders(IAsyncResult result);
    }
}
