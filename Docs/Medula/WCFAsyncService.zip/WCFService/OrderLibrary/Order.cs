﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace WCF.Performance.Samples
{

    [DataContract]
    public class Order
    {
        public Order()
        {
        }

        [DataMember]
        public int OrderID;
        [DataMember]
        public int CustomerID;
        [DataMember]
        public string ShippingAddress1;
        [DataMember]
        public string ShippingAddress2;
        [DataMember]
        public string ShippingCity;
        [DataMember]
        public string ShippingState;
        [DataMember]
        public string ShippingZip;
        [DataMember]
        public string ShippingCountry;
        [DataMember]
        public string ShipType;
        [DataMember]
        public OrderLine[] orderItems;
        [DataMember]
        public string CreditCardType;
        [DataMember]
        public string CreditCardNumber;
        [DataMember]
        public DateTime CreditCardExpiration;
        [DataMember]
        public string CreditCardName;
    }
}
