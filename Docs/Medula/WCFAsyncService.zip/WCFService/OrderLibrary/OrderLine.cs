﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace WCF.Performance.Samples
{
    [DataContract]
    public class OrderLine
    {
        [DataMember]
        public int ItemID;
        [DataMember]
        public int Quantity;
    }
}
