﻿using System;
using System.ServiceModel.Channels;

namespace WCF.Performance.Samples
{
    public static class OrderServiceHelper
    {
        static public Order[] CreateOrders(int numOrders)
        {
            int currentItemID = 0;
            Order[] orders = new Order[numOrders];
            for (int i = 0; i < numOrders; i++)
            {
                Order order = new Order();
                OrderLine[] lines = new OrderLine[2];
                lines[0] = new OrderLine();
                lines[0].ItemID = currentItemID ++;
                lines[0].Quantity = 10;
                lines[1] = new OrderLine();
                lines[1].ItemID = currentItemID ++;
                lines[1].Quantity = 5;
                order.orderItems = lines;
                order.OrderID = i;
                order.CustomerID = numOrders;
                order.ShippingAddress1 = "012345678901234567890123456789";
                order.ShippingAddress2 = "012345678901234567890123456789";
                order.ShippingCity = "0123456789";
                order.ShippingState = "0123456789012345";
                order.ShippingZip = "12345-1234";
                order.ShippingCountry = "United States";
                order.ShipType = "UPS";
                order.CreditCardType = "VISA";
                order.CreditCardNumber = "0123456789012345";
                order.CreditCardExpiration = DateTime.UtcNow;
                order.CreditCardName = "01234567890123456789";
                orders[i] = order;
            }

            return orders;
        }
    }
}
