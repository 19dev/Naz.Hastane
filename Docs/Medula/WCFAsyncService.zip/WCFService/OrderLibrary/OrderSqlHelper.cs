﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Diagnostics;

namespace WCF.Performance.Samples
{
    public class OrderSqlHelper : IDisposable
    {
        #region Constants
        const string ConnectionString = @"Server=LOCALHOST\SQLEXPRESS;Database=MyOrderDatabase;
            Integrated Security=True;
            Asynchronous Processing=True";

        const string DatabaseName = "MyOrderDatabase";
        #endregion

        #region SELECT Query
        const string QueryOrdersText = @"
            SELECT O.OrderID, O.CustomerID, O.ShippingAddress1, O.ShippingAddress2, O.ShippingCity, O.ShippingState, O.ShippingZip, O.ShippingCountry, O.ShipType, 
                O.CreditCardType, O.CreditCardNumber, O.CreditCardExpiration, O.CreditCardName, OL.ItemID, OL.Quantity, OL.Price
            FROM Orders AS O INNER JOIN
                OrderLine AS OL ON O.OrderID = OL.OrderID
            WHERE (O.OrderID IN
                (SELECT TOP (@numOrders) OrderID
                    FROM Orders
                    ORDER BY OrderID))
            ORDER BY O.OrderID
        ";
        #endregion

        #region INSERT Queries
        const string OrdersInsert = @"
            INSERT INTO [{0}].[dbo].[{1}]
                ([CustomerID]
                ,[ShippingAddress1]
                ,[ShippingAddress2]
                ,[ShippingCity]
                ,[ShippingState]
                ,[ShippingZip]
                ,[ShippingCountry]
                ,[ShipType]
                ,[CreditCardType]
                ,[CreditCardNumber]
                ,[CreditCardExpiration]
                ,[CreditCardName]
                ,[OrderID])
            VALUES
                ({2}
                ,'{3}'
                ,'{4}'
                ,'{5}'
                ,'{6}'
                ,'{7}'
                ,'{8}'
                ,'{9}'
                ,'{10}'
                ,'{11}'
                ,'{12}'
                ,'{13}'
                ,'{14}');
            ";

        const string OrdersLineInsert =
            @"INSERT INTO [{0}].[dbo].[{1}]
                ([ItemID]
                ,[OrderID]
                ,[Quantity]
                ,[Price])
             VALUES
                ({2}
                ,{3}
                ,{4}
                ,{5})";
        #endregion

        SqlConnection connection;

        #region Instance Methods
        public OrderSqlHelper()
        {
            this.connection = new SqlConnection(ConnectionString);
            this.connection.Open();

            try
            {
                using (SqlCommand command = this.connection.CreateCommand())
                {
                    command.CommandText = string.Format("use {0}", DatabaseName);
                    command.ExecuteNonQuery();
                }
            }
            catch
            {
                this.connection.Close();
                throw;
            }
        }

        public void ClearTables()
        {
            Execute("delete from OrderLine");
            Execute("delete from Orders");
        }

        public void PopulateOrders(Order[] orders)
        {
            foreach (Order order in orders)
            {
                order.CustomerID = orders.Length;
                string insert = GetInsertOrderCommand(order);

                Execute(insert);
                foreach (OrderLine orderLine in order.orderItems)
                {
                    insert = GetInsertOrderLineCommand(order.OrderID, orderLine);
                    Execute(insert);
                }
            }
        }

        void Execute(string query)
        {
            using (SqlCommand command = this.connection.CreateCommand())
            {
                command.CommandText = query;
                command.ExecuteNonQuery();
            }
        }

        public void Dispose()
        {
            if (this.connection != null)
            {
                this.connection.Close();
                this.connection = null;
            }
        }
        #endregion

        #region Private static methods
        static string GetInsertOrderCommand(Order order)
        {
            return string.Format(OrdersInsert, DatabaseName, "Orders",
                order.CustomerID,
                order.ShippingAddress1,
                order.ShippingAddress2,
                order.ShippingCity,
                order.ShippingState,
                order.ShippingZip,
                order.ShippingCountry,
                order.ShipType,
                order.CreditCardType,
                order.CreditCardNumber,
                order.CreditCardExpiration,
                order.CreditCardName,
                order.OrderID);
        }

        static string GetInsertOrderLineCommand(int orderID, OrderLine orderLine)
        {
            return string.Format(OrdersLineInsert, DatabaseName, "OrderLine",
                orderLine.ItemID,
                orderID,
                orderLine.Quantity,
                0.99M);
        }
        #endregion

        public static IAsyncResult BeginGetOrders(int numOrders, AsyncCallback callback, object state)
        {
            OrderSqlHelper helper = new OrderSqlHelper();
            SqlCommand command = helper.connection.CreateCommand();
            command.CommandText = QueryOrdersText;
            SqlParameter parameter = command.Parameters.Add("@numOrders", System.Data.SqlDbType.Int);
            parameter.Value = numOrders;

            return new SqlGetOrdersAsyncResult(helper, command, callback, state);
        }

        public static Order[] EndGetOrders(IAsyncResult result)
        {
            return SqlGetOrdersAsyncResult.End(result);
        }

        class SqlGetOrdersAsyncResult : AsyncResult
        {
            static AsyncCallback sqlGetOrdersCallback = new AsyncCallback(OnSqlGetOrdersCallback);
            OrderSqlHelper helper;
            SqlCommand command;
            Order[] orders;

            public SqlGetOrdersAsyncResult(OrderSqlHelper helper, SqlCommand command, AsyncCallback callback, object state)
                : base(callback, state)
            {
                this.helper = helper;
                this.command = command;

                IAsyncResult sqlAsyncResult = this.command.BeginExecuteReader(sqlGetOrdersCallback, this);
                if (sqlAsyncResult.CompletedSynchronously)
                {
                    HandleSqlGetOrdersCallback(sqlAsyncResult);
                }
            }

            #region SQL Callback
            static void OnSqlGetOrdersCallback(IAsyncResult result)
            {
                if (result.CompletedSynchronously)
                    return;

                SqlGetOrdersAsyncResult thisObj = result.AsyncState as SqlGetOrdersAsyncResult;
                Debug.Assert(thisObj is SqlGetOrdersAsyncResult, "Invalid 'result' is passed in");

                try
                {
                    thisObj.HandleSqlGetOrdersCallback(result);
                }
                catch (Exception ex)
                {
                    thisObj.Complete(false, ex);
                }
            }
            #endregion

            #region Handle SQL Callback

            void HandleSqlGetOrdersCallback(IAsyncResult result)
            {
                try
                {
                    SqlDataReader reader = this.command.EndExecuteReader(result);
                    FillOrders(reader);
                }
                finally
                {
                    this.helper.Dispose();
                }

                this.Complete(result.CompletedSynchronously);
            }
            #endregion

            #region Orders Property
            Order[] Orders
            {
                get
                {
                    return orders;
                }
            }
            #endregion

            #region End AsyncResult
            public static Order[] End(IAsyncResult result)
            {
                SqlGetOrdersAsyncResult thisObj = result as SqlGetOrdersAsyncResult;
                AsyncResult.End<SqlGetOrdersAsyncResult>(result);

                return thisObj.orders;
            }
            #endregion

            #region Private Methods
            void FillOrders(SqlDataReader reader)
            {
                List<Order> orderList = new List<Order>();
                int lastOrderID = -1;
                int currentOrderID = -1;
                Order currentOrder = null;
                List<OrderLine> items = null;
                while (reader.Read())
                {
                    currentOrderID = (int)reader["OrderID"];
                    if (currentOrderID != lastOrderID)
                    {
                        if (currentOrder != null)
                        {
                            // Copy the items to the current order.
                            currentOrder.orderItems = items.ToArray();
                            items = null;
                        }

                        currentOrder = new Order();
                        currentOrder.OrderID = currentOrderID;
                        currentOrder.CustomerID = (int)reader["CustomerID"];
                        currentOrder.ShippingAddress1 = (string)reader["ShippingAddress1"];
                        currentOrder.ShippingAddress2 = (string)reader["ShippingAddress2"];
                        currentOrder.ShippingCity = (string)reader["ShippingCity"];
                        currentOrder.ShippingState = (string)reader["ShippingState"];
                        currentOrder.ShippingZip = (string)reader["ShippingZip"];
                        currentOrder.ShippingCountry = (string)reader["ShippingCountry"];
                        currentOrder.ShipType = (string)reader["ShipType"];
                        currentOrder.CreditCardType = (string)reader["CreditCardType"];
                        currentOrder.CreditCardNumber = (string)reader["CreditCardNumber"];
                        currentOrder.CreditCardExpiration = (DateTime)reader["CreditCardExpiration"];
                        currentOrder.CreditCardName = (string)reader["CreditCardName"];
                        orderList.Add(currentOrder);

                        items = new List<OrderLine>();
                        lastOrderID = currentOrderID;
                    }

                    OrderLine item = new OrderLine();
                    item.ItemID = (int)reader["ItemID"];
                    item.Quantity = (int)reader["Quantity"];
                    items.Add(item);
                }

                if (currentOrder != null && items != null)
                {
                    // Copy the items to the current order.
                    currentOrder.orderItems = items.ToArray();
                }

                this.orders = orderList.ToArray();
            }
            #endregion
        }
    }
}
