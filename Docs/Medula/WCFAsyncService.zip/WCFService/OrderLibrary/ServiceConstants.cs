﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WCF.Performance.Samples
{
    static class ServiceConstants
    {
        internal const string ServiceName = "MyOrderService";
        internal const string ServiceNamespace = "http://blog.microsoft.com/wcfwfperf/";
        internal const string ServiceContractNamespace = ServiceNamespace + "MyOrderService/";
        internal const string GetOrdersAction = ServiceContractNamespace + "GetOrders";
        internal const string GetOrderReplyAction = GetOrdersAction + "Response";
        internal const string SendOrdersAction = ServiceContractNamespace + "SendOrders";
        internal const string SendOrderReplyAction = SendOrdersAction + "Response";
    }
}
