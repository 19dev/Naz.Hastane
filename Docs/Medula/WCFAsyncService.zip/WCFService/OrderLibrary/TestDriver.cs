﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace WCF.Performance.Samples
{
    public abstract class TestDriver
    {
        int runCount = 0;
        int endWarmupTicks;
        int endRunTicks;

        int warmupSeconds = 2;
        int totalRunSeconds = 5;
        int startMeasurement;
        double rate;
        object syncRoot = new object();

        protected int WarmupSeconds
        {
            get
            {
                return this.warmupSeconds;
            }

            set
            {
                this.warmupSeconds = value;
            }
        }

        protected int TotalRunSeconds
        {
            get
            {
                return this.totalRunSeconds;
            }

            set
            {
                this.totalRunSeconds = value;
            }
        }

        protected void Run(string[] args)
        {
            Console.WriteLine("Setup test");
            SetupTest();

            Console.WriteLine("Run test");
            endWarmupTicks = Environment.TickCount + WarmupSeconds * 1000;
            endRunTicks = endWarmupTicks + totalRunSeconds * 1000;
            RunTest();
            Console.WriteLine("Run complete");
            Summarize();
            Console.WriteLine("Total counts: {0}", this.runCount);
            Console.WriteLine("Duration: {0}", this.totalRunSeconds);
            Console.WriteLine("Throughput: {0} ops/sec", this.Rate);
        }

        protected virtual void SetupTest() { }
        protected abstract void RunTest();
        protected bool RunComplete()
        {
            if (Environment.TickCount < endWarmupTicks)
                return false;
            else if (Environment.TickCount < endRunTicks)
            {
                if (startMeasurement == 0)
                {
                    if (Interlocked.Exchange(ref startMeasurement, 1) == 0)
                    {
                        Console.WriteLine("Start measurement");
                    }
                }

                Interlocked.Increment(ref runCount);
                return false;
            }

            return true;
        }

        void Summarize()
        {
            rate = (double)runCount / totalRunSeconds;
        }

        protected double Rate
        {
            get
            {
                return this.rate;
            }
        }
    }
}
