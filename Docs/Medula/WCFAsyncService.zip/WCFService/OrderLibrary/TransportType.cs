﻿namespace WCF.Performance.Samples
{
    public enum TransportType
    {
        Http,
        Tcp,
        Pipe
    }
}
