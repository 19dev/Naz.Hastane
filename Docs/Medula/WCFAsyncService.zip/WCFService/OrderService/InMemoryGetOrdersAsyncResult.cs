﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace WCF.Performance.Samples
{
    class InMemoryGetOrdersAsyncResult : AsyncResult
    {
        static Func<int, Order[]> getOrdersFunc = new Func<int, Order[]>(GetOrders);
        IAsyncResult innerAsyncResult;
        Order[] orders;

        public InMemoryGetOrdersAsyncResult(int numOrders, AsyncCallback callback, object state)
            : base(callback, state)
        {
            innerAsyncResult = getOrdersFunc.BeginInvoke(numOrders, new AsyncCallback(OnGetOrders), state);
            if (innerAsyncResult.CompletedSynchronously)
            {
                HandleOrders(innerAsyncResult);
            }
        }

        void OnGetOrders(IAsyncResult result)
        {
            if (result.CompletedSynchronously)
                return;

            HandleOrders(result);
        }

        void HandleOrders(IAsyncResult result)
        {
            this.orders = getOrdersFunc.EndInvoke(result);
            this.Complete(result.CompletedSynchronously);
        }

        static Order[] GetOrders(int numOrders)
        {
            Thread.Sleep(1000);
            return OrderServiceHelper.CreateOrders(numOrders);
        }

        public static Order[] End(IAsyncResult result)
        {
            InMemoryGetOrdersAsyncResult thisObj = result as InMemoryGetOrdersAsyncResult;
            AsyncResult.End<InMemoryGetOrdersAsyncResult>(result);

            return thisObj.orders;
        }
    }
}
