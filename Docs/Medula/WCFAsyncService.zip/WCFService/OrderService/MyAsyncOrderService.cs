﻿#define USE_SQL
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Data.SqlClient;
using System.ServiceModel.Channels;

namespace WCF.Performance.Samples
{
    [ServiceBehavior(Name = "MyOrderService")]
    public class MyAsyncOrderService : IAsyncOrderService
    {
        public MyAsyncOrderService() {}

        public IAsyncResult BeginGetOrders(int numOrders, AsyncCallback callback, object state)
        {
            return OrderSqlHelper.BeginGetOrders(numOrders, callback, state);
            // return new InMemoryGetOrdersAsyncResult(numOrders, callback, state);
        }

        public Order[] EndGetOrders(IAsyncResult result)
        {
            return OrderSqlHelper.EndGetOrders(result);
            // return InMemoryGetOrdersAsyncResult.End(result);
        }
    }
}
