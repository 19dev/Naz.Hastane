USE [master]
GO
IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'MyOrderDatabase')
DROP DATABASE [MyOrderDatabase]
GO
CREATE DATABASE [MyOrderDatabase]
GO	
USE [MyOrderDatabase]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Orders]') AND type in (N'U'))
DROP TABLE [dbo].[Orders]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrderLine]') AND type in (N'U'))
DROP TABLE [dbo].[OrderLine]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Orders]') AND type in (N'U'))
BEGIN
CREATE TABLE Orders (
	CustomerID int NOT NULL,
	ShippingAddress1 varchar(100) NULL,
	ShippingAddress2 varchar(100) NULL,
	ShippingCity varchar(50) NULL,
	ShippingState varchar(50) NULL,
	ShippingZip varchar(50) NULL,
	ShippingCountry varchar(50) NULL,
	ShipType varchar(50) NULL,
	CreditCardType varchar(50) NULL,
	CreditCardNumber varchar(50) NULL,
	CreditCardExpiration DATETIME NOT NULL DEFAULT(getdate()),
	CreditCardName varchar(50) NULL,
	OrderID int NOT NULL,
	CONSTRAINT [PK_Orders] PRIMARY KEY CLUSTERED 
	(
		[OrderID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OrderLine]') AND type in (N'U'))
BEGIN
CREATE TABLE .OrderLine(
	ItemID int NOT NULL,
	OrderID int NULL,
	Quantity int NULL,
	Price decimal(18, 4) NULL,
	CONSTRAINT PK_OrderLine PRIMARY KEY CLUSTERED 
	(
		ItemID ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
