Here are the steps of how to setup SQL database:
1) Run SetupSQL.bat

To cleanup, run the following:
1) Run CleanupSQL.bat
