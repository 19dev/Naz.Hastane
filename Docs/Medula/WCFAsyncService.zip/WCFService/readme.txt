How to use the sample?
-----------------------
Prerequisite:
1) You have Windows 2008
2) You have installed VS 2008
3) You have SQL Express installed
4) You have IIS, IIS Management tools, WCF HTTP Activation components installed.

Here are the steps to run the test:
1) Open the solution file "WCFOrderService.sln" with VS 2008 and compile the whole solution with "Release" type.
2) Run "SQL\SetupSQL.bat" to create database "MyOrderDatabase".
3) Run "OrderCreator\bin\Release\OrderCreator.exe 1000" to insert 1000 distinct orders into database.
4) Open IIS Manager, create a virtual application that points to the full path of "OrderService".
5) Use IIS Manager to configure the default ApplicationPool to have identity "OrderPerfUser". This user was created in step 2) above.
6) Browse the OrderService.svc file in the browser. Make sure that you can see the WCF service correctly responds to the request from browser.
7) Run the client "OrderClient\bin\Release\OrderClient.exe"
8) Tune different parameters in the OrderService\web.config and OrderClient\bin\Release\OrderClient.exe.config
9) Use the tool "Tools\WcfAsyncWebUtil.exe" to configure WCF to use the async HttpModule and increase the ASP.NET registry "MaxConcurrentRequestsPerCpu". Run the test again to see the difference.
10) Open PerfMon to monitor requests such as "Calls Outstanding" counter.
